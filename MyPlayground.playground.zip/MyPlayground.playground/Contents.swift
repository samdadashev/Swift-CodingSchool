

import Foundation


 /*   //   // MARK: - Word Reverse
let string = "Coding School"
var reverseString = ""
for str in string {
   reverseString.insert(str, at: reverseString.startIndex)
}
print(reverseString)

let example = " musterman"
var reverseMuster = ""
for str in example{
    reverseMuster.insert(str, at: reverseMuster.startIndex)
}
print(reverseMuster)
*/

// MARK: - Time
/*
print("-- TIME --")
let t1 = time(hour: 3, minute: 20, second: 45)
let t2 = time(hour: 1, minute: 20, second: 45)
let t3 = time()

evaluate(t1.subtracting(t2).description, expected: "02:00:00")
evaluate(t2.adding(seconds: 120).description, expected: "01:22:45")

t3.set(.hour, to: 1)
evaluate(t3.value(for: .hour), expected: 1)
evaluate(t3.description, expected: "01:00:00")

t3.set(.minute, to: 30)
evaluate(t3.value(for: .minute), expected: 30)
evaluate(t3.description, expected: "01:30:00")

t3.set(.second, to: 5)
evaluate(t3.value(for: .second), expected: 5)
evaluate(t3.description, expected: "01:30:05")

// MARK: - Addendum Time
// FILL IN
}
}

Evaluator.evaluate()

*/























